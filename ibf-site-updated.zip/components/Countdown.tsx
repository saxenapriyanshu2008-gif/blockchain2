"use client";
import { useEffect, useState } from "react";
export default function Countdown({ to }: { to: string }) {
  const [ms, setMs] = useState<number | null>(null);
  useEffect(() => { const t = () => setMs(Math.max(0, +new Date(to) - Date.now())); t(); const i = setInterval(t, 1000); return () => clearInterval(i); }, [to]);
  if (ms === null) return null;
  const parts = [["days", Math.floor(ms / 864e5)], ["hrs", Math.floor(ms / 36e5) % 24], ["min", Math.floor(ms / 6e4) % 60], ["sec", Math.floor(ms / 1e3) % 60]] as const;
  return <div className="grid w-full grid-cols-4 gap-2 md:flex md:w-auto md:gap-3" aria-label="Time until event">{parts.map(([l, v]) => (
    <div key={l} className="glass p-2.5 text-center md:min-w-16 md:p-3"><div className="font-display text-2xl text-white">{String(v).padStart(2, "0")}</div><div className="text-xs">{l}</div></div>))}</div>;
}
