"use client";
import { useState } from "react";
export type Field = { name: string; label: string; type?: string; required?: boolean; options?: string[] };
export default function Form({ type, fields, submit = "Send" }: { type: string; fields: Field[]; submit?: string }) {
  const [state, setState] = useState<"idle" | "sending" | "ok" | "error">("idle");
  const [msg, setMsg] = useState("");
  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setState("sending");
    const data = Object.fromEntries(new FormData(e.currentTarget));
    const res = await fetch(`/api/forms/${type}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(data) });
    const j = await res.json().catch(() => ({}));
    setState(res.ok ? "ok" : "error"); setMsg(j.error ?? "");
  }
  if (state === "ok") return <p role="status" className="glass p-6 text-ember">Thanks, we have your details and will reply soon.</p>;
  const cls = "mt-1 w-full rounded-lg border border-white/15 bg-white/5 px-3 py-2 text-white focus-visible:outline focus-visible:outline-2 focus-visible:outline-volt";
  return (
    <form onSubmit={onSubmit} className="glass grid gap-4 p-5 md:p-6">
      {fields.map(f => (
        <label key={f.name} className="block text-sm">{f.label}{f.required && " *"}
          {f.options ? <select name={f.name} required={f.required} className={cls}>{f.options.map(o => <option key={o}>{o}</option>)}</select>
            : f.type === "textarea" ? <textarea name={f.name} required={f.required} rows={4} className={cls} />
            : <input name={f.name} type={f.type ?? "text"} required={f.required} className={cls} />}
        </label>))}
      <input name="website" tabIndex={-1} autoComplete="off" aria-hidden className="hidden" /> {/* honeypot */}
      {state === "error" && <p role="alert" className="text-red-400">{msg || "Something went wrong. Check the fields and try again."}</p>}
      <button disabled={state === "sending"} className="btn bg-gradient-to-r from-volt to-violet text-white disabled:opacity-60">{state === "sending" ? "Sending…" : submit}</button>
    </form>);
}
