import Link from "next/link";
import { nav, site } from "@/data/site";
import GlassSurface from "./GlassSurface";
import MobileMenu from "./MobileMenu";

// Mobile: the two most important links stay in the bar; everything else lives in the hamburger drawer on the left.
const quick = [{ label: "Events", href: "/events" }, { label: "Join IBF", href: "/join" }];
const drawer = nav.flatMap(n =>
  n.label === "Events" ? [{ label: "Past events", href: "/events/past" }]
  : n.label === "Community" ? (n.children ?? []).filter(c => c.href !== "/join")
  : [n]);

export default function Navbar() {
  return (
    <header className="pointer-events-none sticky top-2 z-50 -mb-[76px] px-2 sm:top-3 sm:px-3">
      <div className="pointer-events-auto mx-auto max-w-6xl">
        <GlassSurface width="100%" height="auto" borderRadius={28} backgroundOpacity={0.12} distortionScale={-110} displace={0.5} blur={14}
          style={{ overflow: "visible", background: "rgba(10,9,24,.45)" }}>
          <nav aria-label="Main" className="flex w-full flex-nowrap items-center justify-between gap-2 px-1.5 py-1 lg:gap-4 lg:px-3 lg:py-1.5">
            {/* mobile / tablet: [☰] IBF ........ Events  Join IBF  (one row) */}
            <div className="flex min-w-0 items-center gap-1 lg:hidden">
              <MobileMenu items={drawer} brand={site.name} />
              <Link href="/" className="font-display text-lg font-bold text-white">{site.short}</Link>
            </div>
            <div className="flex shrink-0 items-center gap-1.5 lg:hidden">
              <Link href={quick[0].href} className="rounded-full px-3 py-2 text-sm font-medium text-slate-100 active:bg-white/10">{quick[0].label}</Link>
              <Link href={quick[1].href} className="whitespace-nowrap rounded-full bg-volt px-3.5 py-2 text-sm font-semibold text-white active:opacity-80">{quick[1].label}</Link>
            </div>
            {/* desktop */}
            <Link href="/" className="hidden font-display text-lg font-bold text-white lg:block">{site.short}</Link>
            <ul className="hidden flex-wrap items-center justify-end gap-x-5 gap-y-1 text-sm lg:flex">
              {nav.map(n => (
                <li key={n.label} className="group relative">
                  <Link href={n.href} className="py-2 text-slate-100 hover:text-ember focus-visible:text-ember">{n.label}</Link>
                  {n.children && (
                    <ul className="invisible absolute left-0 top-full min-w-40 rounded-2xl border border-white/15 bg-ink/90 p-2 opacity-0 backdrop-blur-xl transition group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                      {n.children.map(c => <li key={c.href}><Link href={c.href} className="block rounded-lg px-3 py-1.5 hover:bg-white/10">{c.label}</Link></li>)}
                    </ul>)}
                </li>))}
            </ul>
          </nav>
        </GlassSurface>
      </div>
    </header>);
}
