"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import VaporizeTextCycle, { Tag } from "@/components/ui/vapour-text-effect";

// Module-level constants so the vapour component never sees "new" props on re-render
const TEXTS = ["IBF\nBennett University"]; // one block, two lines: appears together, vanishes together
const LINE_SCALES = [1, 0.4];  // "Bennett University" is 40% the size of "IBF" so it fits on one line
const ANIMATION = { vaporizeDuration: 1, fadeInDuration: 0.5, waitDuration: 1 };

/**
 * Opening screen: "IBF" over "Bennett" are drawn together as particles and vaporize away as one,
 * then the page underneath is revealed. Shown once per browser session; click / Esc / Enter skips.
 */
export default function IntroSplash() {
  const [open, setOpen] = useState(true);
  const [fading, setFading] = useState(false);
  const [fontFamily, setFontFamily] = useState("system-ui, sans-serif");
  const [fontSize, setFontSize] = useState("96px");
  const done = useRef(false);

  const finish = useCallback(() => {
    if (done.current) return; done.current = true;
    try { sessionStorage.setItem("ibf-intro", "1"); } catch {}
    document.documentElement.style.overflow = "";
    setFading(true);
    setTimeout(() => setOpen(false), 500);
  }, []);

  useEffect(() => {
    let seen = false;
    try { seen = sessionStorage.getItem("ibf-intro") === "1"; } catch {}
    if (seen) { done.current = true; setOpen(false); return; }
    document.documentElement.style.overflow = "hidden";

    // The canvas can't use CSS variables, so resolve the real next/font family name
    const v = getComputedStyle(document.documentElement).getPropertyValue("--font-display").trim();
    if (v) setFontFamily(`${v}, system-ui, sans-serif`);
    setFontSize(`${Math.round(Math.max(48, Math.min(150, window.innerWidth * 0.2, window.innerHeight * 0.3)))}px`);

    const key = (e: KeyboardEvent) => { if (e.key === "Escape" || e.key === "Enter") finish(); };
    window.addEventListener("keydown", key);
    return () => { window.removeEventListener("keydown", key); document.documentElement.style.overflow = ""; };
  }, [finish]);

  const font = useRef({ fontFamily, fontSize, fontWeight: 700 });
  if (font.current.fontFamily !== fontFamily || font.current.fontSize !== fontSize) font.current = { fontFamily, fontSize, fontWeight: 700 };

  if (!open) return null;
  return (
    <div role="dialog" aria-label="Welcome to IBF at Bennett University" onClick={finish}
      className="fixed inset-0 z-[100] cursor-pointer bg-ink transition-opacity duration-500" style={{ opacity: fading ? 0 : 1 }}>
      <VaporizeTextCycle
        texts={TEXTS}
        lineScales={LINE_SCALES}
        font={font.current}
        color="rgb(255, 255, 255)"
        spread={5}
        density={5}
        animation={ANIMATION}
        direction="left-to-right"
        alignment="center"
        tag={Tag.H1}
        onComplete={finish}
      />
      <p className="absolute inset-x-0 bottom-6 text-center text-xs tracking-widest text-white/40">CLICK TO SKIP</p>
    </div>);
}
