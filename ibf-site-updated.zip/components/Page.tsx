export default function Page({ title, intro, children }: { title: string; intro?: string; children?: React.ReactNode }) {
  return (<div className="mx-auto max-w-6xl px-4 pb-12 pt-24 md:pb-16 md:pt-28"><h1 className="text-3xl font-bold sm:text-4xl md:text-5xl">{title}</h1>
    {intro && <p className="mt-4 max-w-2xl text-lg">{intro}</p>}<div className="mt-10 grid gap-10">{children}</div></div>);
}
