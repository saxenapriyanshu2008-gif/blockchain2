"use client";
import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import Link from "next/link";
import { usePathname } from "next/navigation";

type Item = { label: string; href: string; children?: { label: string; href: string }[] };

/** Hamburger (three dashes) on the left of the top bar. Opens a slide-in drawer with the less important links. */
export default function MobileMenu({ items, brand }: { items: Item[]; brand: string }) {
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const path = usePathname();

  useEffect(() => setMounted(true), []);
  useEffect(() => setOpen(false), [path]);            // close after navigating
  useEffect(() => {
    if (!open) return;
    const prev = document.documentElement.style.overflow;
    document.documentElement.style.overflow = "hidden"; // lock page scroll behind the drawer
    const key = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", key);
    return () => { document.documentElement.style.overflow = prev; window.removeEventListener("keydown", key); };
  }, [open]);

  return (<>
    <button type="button" aria-label="Open menu" aria-expanded={open} aria-controls="mobile-drawer" onClick={() => setOpen(true)}
      className="grid h-10 w-10 shrink-0 place-items-center rounded-full text-white active:bg-white/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-ember">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden><path d="M4 7h16M4 12h16M4 17h16" /></svg>
    </button>
    {mounted && createPortal(
      <div className={`fixed inset-0 z-[60] lg:hidden ${open ? "visible" : "invisible"} transition-[visibility] duration-300`} aria-hidden={!open}>
        <div onClick={() => setOpen(false)} className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${open ? "opacity-100" : "opacity-0"}`} />
        <aside id="mobile-drawer" role="dialog" aria-modal="true" aria-label="Menu"
          className={`absolute inset-y-0 left-0 flex w-[82%] max-w-xs flex-col border-r border-white/10 bg-ink/95 shadow-2xl transition-transform duration-300 ease-out ${open ? "translate-x-0" : "-translate-x-full"}`}>
          <div className="flex items-center justify-between px-4 py-3">
            <span className="font-display text-lg font-bold text-white">{brand}</span>
            <button type="button" aria-label="Close menu" onClick={() => setOpen(false)} className="grid h-10 w-10 place-items-center rounded-full text-white active:bg-white/10">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden><path d="M6 6l12 12M18 6L6 18" /></svg>
            </button>
          </div>
          <nav aria-label="More" className="flex-1 overflow-y-auto px-2 pb-8">
            <ul className="grid gap-1">
              {items.map(i => (
                <li key={i.label}>
                  <Link href={i.href} className="block rounded-xl px-3 py-3 text-base font-medium text-slate-100 active:bg-white/10 hover:text-ember">{i.label}</Link>
                  {i.children && (
                    <ul className="mb-1 ml-3 grid gap-0.5 border-l border-white/10 pl-2">
                      {i.children.map(c => <li key={c.href}><Link href={c.href} className="block rounded-lg px-3 py-2 text-sm text-slate-300 active:bg-white/10 hover:text-ember">{c.label}</Link></li>)}
                    </ul>)}
                </li>))}
            </ul>
          </nav>
        </aside>
      </div>, document.body)}
  </>);
}
