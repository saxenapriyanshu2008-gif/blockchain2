"use client";
import { useEffect, useRef } from "react";

/** Cursor-following blue glow over the hero. Must be rendered inside the hero <section>. */
export default function HeroFx() {
  const glow = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const hero = glow.current?.closest("section");
    if (!hero) return;
    const move = (e: PointerEvent) => {
      const r = hero.getBoundingClientRect();
      hero.style.setProperty("--mx", `${e.clientX - r.left}px`);
      hero.style.setProperty("--my", `${e.clientY - r.top}px`);
      hero.style.setProperty("--glow", "1");
    };
    const leave = () => hero.style.setProperty("--glow", "0");
    hero.addEventListener("pointermove", move);
    hero.addEventListener("pointerleave", leave);
    return () => { hero.removeEventListener("pointermove", move); hero.removeEventListener("pointerleave", leave); };
  }, []);
  return <div ref={glow} aria-hidden className="hero-glow" />;
}
