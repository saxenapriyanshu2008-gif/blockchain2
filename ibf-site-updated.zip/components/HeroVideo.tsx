"use client";
import { useEffect, useRef } from "react";

/** Hero banner video: muted autoplay, seamless loop (the file's last frames crossfade into its first),
 *  and it pauses while off-screen / tab hidden so it never competes with scrolling. */
export default function HeroVideo() {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    const v = ref.current; if (!v) return;
    v.muted = true;
    const play = () => { v.play().catch(() => {}); };
    play();
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting && !document.hidden) play(); else v.pause(); }, { threshold: 0.05 });
    io.observe(v);
    const vis = () => { if (document.hidden) v.pause(); else play(); };
    document.addEventListener("visibilitychange", vis);
    // safety net: if a browser ever ends the loop, restart instantly
    const ended = () => { v.currentTime = 0; play(); };
    v.addEventListener("ended", ended);
    return () => { io.disconnect(); document.removeEventListener("visibilitychange", vis); v.removeEventListener("ended", ended); };
  }, []);
  return (
    <video ref={ref} autoPlay muted loop playsInline disablePictureInPicture preload="auto" poster="/hero-poster.jpg"
      aria-label="India Blockchain Federation Club at Bennett University: learn, build, connect, grow"
      className="block h-auto w-full [mask-image:linear-gradient(to_bottom,transparent,black_6%,black_88%,transparent)] [transform:translateZ(0)]" width={1440} height={720}>
      <source src="/hero.mp4" type="video/mp4" />
    </video>);
}
