"use client";
import { useEffect, useState } from "react";
import InfiniteSpiral from "./InfiniteSpiral";
import PatternWaves from "./PatternWaves";

const photos = [
  ["/gallery-1.jpg", "Hack night"], ["/gallery-3.jpg", "Community day"], ["/gallery-4.jpg", "Build on TON"], ["/gallery-7.jpg", "The crew"],
  ["/gallery-2.jpg", "Workshop floor"], ["/gallery-5.jpg", "Questions"], ["/hero-right.jpg", "Group photo"], ["/gallery-6.jpg", "Full house"],
  ["/hero-left.jpg", "Bootcamp"], ["/gallery-1.jpg", "Front row"], ["/gallery-3.jpg", "Squad goals"], ["/gallery-5.jpg", "Hands on"],
  ["/gallery-2.jpg", "Learning together"], ["/gallery-4.jpg", "Workshop"],
].map(([src, alt]) => ({ src, alt: `${alt} at an IBF event` })); // TODO: real photos

/** Heading on the left, photo spiral on the right (separate columns, so they never overlap), over animated waves. */
export default function ScrollGallery() {
  const [narrow, setNarrow] = useState(false);
  useEffect(() => { const m = window.matchMedia("(max-width: 767px)"); const f = () => setNarrow(m.matches); f(); m.addEventListener("change", f); return () => m.removeEventListener("change", f); }, []);
  return (
    <section aria-label="Gallery" className="relative w-full overflow-hidden">
      <div aria-hidden className="absolute inset-0">
        <PatternWaves preset="silk" color="#6f8dff" backgroundColor="#07060F" fade="edges" fadeSize={0.6} opacity={0.7} interactive cursorSize={60} cursorStrength={0.6} />
      </div>
      <div className="relative z-10 mx-auto grid max-w-7xl items-center gap-4 px-4 py-12 md:min-h-[720px] md:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] md:gap-8 md:py-16">
        <div className="text-center md:pl-4 md:text-left">
          <p className="text-sm font-semibold uppercase tracking-[0.25em] text-ember">Gallery</p>
          <h2 className="mt-3 text-4xl font-bold leading-[1.05] sm:text-5xl md:text-7xl">Moments from our events</h2>
          <p className="mx-auto mt-4 max-w-md text-base text-slate-300 md:mx-0 md:mt-5 md:text-lg">Hackathons, workshops and late-night builds. Scroll, drag or just watch the spiral turn.</p>
        </div>
        <div className="relative h-[440px] sm:h-[520px] md:h-[680px]">
          <InfiniteSpiral items={photos} animationMode="all" speed={0.5} radius={narrow ? 130 : 240} cardWidth={narrow ? 118 : 160} cardHeight={narrow ? 150 : 200} verticalSpacing={narrow ? 66 : 82}
            perspective={1000} cardRadius={14} centerScale={1.25} edgeBlur={6} cardsPerTurn={7} pauseOnHover />
        </div>
      </div>
    </section>);
}
