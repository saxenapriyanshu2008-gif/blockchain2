"use client";
import { useEffect, useRef, useState } from "react";
import { useInView } from "framer-motion";
export default function Counter({ value }: { value: number }) {
  const ref = useRef(null); const seen = useInView(ref, { once: true }); const [n, setN] = useState(0);
  useEffect(() => { if (!seen) return; let f = 0; const id = setInterval(() => { f++; setN(Math.round(value * Math.min(1, f / 40))); if (f >= 40) clearInterval(id); }, 30); return () => clearInterval(id); }, [seen, value]);
  return <span ref={ref}>{n.toLocaleString("en-IN")}+</span>;
}
