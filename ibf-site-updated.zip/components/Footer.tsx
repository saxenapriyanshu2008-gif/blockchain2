import Link from "next/link";
import Form from "./Form";
import { nav, site } from "@/data/site";
import { deckUrl } from "@/data/pages";
export default function Footer() {
  return (
    <footer className="mt-16 border-t md:mt-24 border-white/10">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 md:gap-10 md:py-12 md:grid-cols-3">
        <div><p className="font-display text-xl text-white">{site.name}</p><p className="mt-2 text-sm">{site.tagline}</p>
          <p className="mt-4 text-sm">{/* TODO: real socials */}<a href="#" className="hover:text-ember">X</a> · <a href="#" className="hover:text-ember">Instagram</a> · <a href="#" className="hover:text-ember">LinkedIn</a></p></div>
        <ul className="grid grid-cols-2 gap-2 text-sm">{nav.map(n => <li key={n.label}><Link href={n.href} className="hover:text-ember">{n.label}</Link></li>)}<li><a href={deckUrl} target="_blank" rel="noopener noreferrer" className="hover:text-ember">Sponsorship deck</a></li></ul>
        <div><p className="mb-2 text-white">Get event updates</p><Form type="newsletter" submit="Subscribe" fields={[{ name: "email", label: "Email", type: "email", required: true }]} /></div>
      </div>
    </footer>);
}
