import type { ComponentType } from "react";
export type SpiralItem = string | { src: string; alt?: string; href?: string; target?: string; label?: string; id?: string | number };
declare const InfiniteSpiral: ComponentType<{ items?: SpiralItem[]; speed?: number; direction?: "up" | "down"; animationMode?: "auto" | "drag" | "scroll" | "all"; radius?: number; cardWidth?: number; cardHeight?: number; verticalSpacing?: number; perspective?: number; cardsPerTurn?: number; rotation?: number; cardTilt?: number; cardRadius?: number; centerScale?: number; edgeFade?: number; edgeBlur?: number; pauseOnHover?: boolean; imageFit?: "cover" | "contain"; grayscale?: number; className?: string }>;
export default InfiniteSpiral;
