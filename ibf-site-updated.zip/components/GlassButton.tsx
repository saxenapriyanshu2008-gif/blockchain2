import Link from "next/link";
import GlassSurface from "./GlassSurface";

/** Liquid-glass pill button. tone tints the glass: "blue" (primary), "amber" (sponsor), "clear". */
const tints = { blue: "rgba(77,124,255,.38)", amber: "rgba(255,166,43,.42)", clear: "rgba(255,255,255,.06)" } as const;
export default function GlassButton({ href, children, tone = "clear" }: { href: string; children: React.ReactNode; tone?: keyof typeof tints }) {
  return (
    <Link href={href} className="inline-block rounded-full transition hover:scale-[1.04] focus-visible:outline focus-visible:outline-2 focus-visible:outline-ember">
      <GlassSurface width="auto" height={52} borderRadius={26} backgroundOpacity={0.1} distortionScale={-120} displace={0.4} style={{ background: tints[tone] }}>
        <span className="whitespace-nowrap px-5 font-semibold text-white">{children}</span>
      </GlassSurface>
    </Link>);
}
