import Form from "@/components/Form";
export const metadata = { title: "Join IBF" };
export default function Join() {
  return (<div className="mx-auto max-w-xl px-4 py-16"><h1 className="mb-6 text-4xl">Join IBF</h1>
    <Form type="join" submit="Join the community" fields={[
      { name: "name", label: "Full name", required: true }, { name: "email", label: "Email", type: "email", required: true },
      { name: "phone", label: "Phone", type: "tel" }, { name: "college", label: "College", required: true },
      { name: "year", label: "Year", options: ["1st", "2nd", "3rd", "4th", "Other"] },
      { name: "interests", label: "Interests", type: "textarea" }, { name: "wallet", label: "Wallet or GitHub (optional)" }]} /></div>);
}
