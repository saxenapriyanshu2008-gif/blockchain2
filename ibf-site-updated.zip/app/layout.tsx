import type { Metadata, Viewport } from "next";
import { Space_Grotesk, Inter } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { site } from "@/data/site";
const display = Space_Grotesk({ subsets: ["latin"], variable: "--font-display" });
const body = Inter({ subsets: ["latin"], variable: "--font-body" });
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#07060F" };
export const metadata: Metadata = {
  metadataBase: new URL(site.url), icons: { icon: "/favicon.svg" }, title: { default: `${site.name} (IBF)`, template: `%s | ${site.short}` }, description: site.pitch,
  openGraph: { title: site.name, description: site.tagline, type: "website", images: ["/og.png"] /* TODO add og.png */ } };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en" className={`${display.variable} ${body.variable}`}><body>
    <a href="#main" className="sr-only focus:not-sr-only">Skip to content</a><Navbar /><main id="main">{children}</main><Footer /></body></html>);
}
