import Page from "@/components/Page";
import { team } from "@/data/pages";
export const metadata = { title: "Core team" };
export default function Team() {
  return (<Page title="Core team"><div className="grid gap-4 md:grid-cols-3">{team.map((m, i) => (
    <article key={i} className="glass p-6"><div className="mb-4 h-20 w-20 rounded-full bg-gradient-to-br from-volt to-violet" aria-hidden /><h2 className="text-lg">{m.name}</h2>
      <p className="text-ember">{m.role}</p><p className="mt-2 text-sm">{m.bio}</p><p className="mt-3 text-sm"><a href={m.linkedin} className="hover:text-ember">LinkedIn</a> · <a href={m.x} className="hover:text-ember">X</a></p></article>))}</div></Page>);
}
