import { notFound } from "next/navigation";
import Page from "@/components/Page";
import { initiativePages } from "@/data/pages";
export const generateStaticParams = () => Object.keys(initiativePages).map(slug => ({ slug }));
export default function Initiative({ params }: { params: { slug: string } }) {
  const p = initiativePages[params.slug]; if (!p) notFound();
  return (<Page title={p.title} intro={p.intro}><ul className="grid gap-4 md:grid-cols-2">{p.items.map(i => (
    <li key={i.name} className="glass p-6"><h2 className="text-xl">{i.name}</h2><p className="mt-2">{i.detail}</p>{i.link && <a href={i.link} className="mt-3 inline-block text-ember">View</a>}</li>))}</ul></Page>);
}
