import { NextResponse } from "next/server";
const TYPES = ["join", "event", "sponsor", "chapter", "contact", "newsletter"];
export async function POST(req: Request, { params }: { params: { type: string } }) {
  if (!TYPES.includes(params.type)) return NextResponse.json({ error: "Unknown form" }, { status: 404 });
  const body = await req.json().catch(() => null);
  if (!body || typeof body !== "object") return NextResponse.json({ error: "Invalid request" }, { status: 400 });
  if (body.website) return NextResponse.json({ ok: true }); // honeypot: silently drop bots
  if (body.email !== undefined && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(String(body.email))) return NextResponse.json({ error: "Enter a valid email address." }, { status: 422 });
  // TODO: add rate limiting (e.g. Upstash) and Turnstile/reCAPTCHA verification here.
  const { website, ...row } = body;
  const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_KEY; // TODO: set in .env.local
  if (url && key) {
    const r = await fetch(`${url}/rest/v1/submissions`, { method: "POST", headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" }, body: JSON.stringify({ form: params.type, data: row }) });
    if (!r.ok) return NextResponse.json({ error: "Could not save. Try again later." }, { status: 502 });
  } else console.log("[form]", params.type, row);
  return NextResponse.json({ ok: true });
}
