import Page from "@/components/Page";
import Form from "@/components/Form";
import { chapters } from "@/data/pages";
export const metadata = { title: "Chapters" };
export default function Chapters() { // TODO: interactive India map
  return (<Page title="Chapters" intro="IBF chapters across Indian universities.">
    <ul className="grid gap-3 md:grid-cols-4">{chapters.map(c => <li key={c} className="glass p-4">{c}</li>)}</ul>
    <section className="max-w-xl"><h2 className="mb-3 text-2xl">Start a chapter</h2><Form type="chapter" submit="Apply" fields={[{ name: "name", label: "Your name", required: true }, { name: "email", label: "Email", type: "email", required: true }, { name: "college", label: "College", required: true }, { name: "message", label: "Why start a chapter?", type: "textarea" }]} /></section></Page>);
}
