import { site, nav } from "@/data/site";
export default function sitemap() { return ["/", ...nav.flatMap(n => [n.href, ...(n.children?.map(c => c.href) ?? [])])].map(p => ({ url: site.url + p })); }
