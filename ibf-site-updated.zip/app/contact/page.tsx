import Page from "@/components/Page";
import Form from "@/components/Form";
import { faqs } from "@/data/pages";
export const metadata = { title: "Contact" };
export default function Contact() {
  return (<Page title="Contact" intro="Email hello@ibf.example.com">
    <div className="grid gap-8 md:grid-cols-2"><Form type="contact" fields={[{ name: "name", label: "Name", required: true }, { name: "email", label: "Email", type: "email", required: true }, { name: "message", label: "Message", type: "textarea", required: true }]} />
      <div><p className="mb-3">Bennett University, Greater Noida, Uttar Pradesh</p>{/* TODO: Google Maps embed */}<div className="glass h-48" aria-hidden /></div></div>
    <section><h2 className="mb-3 text-2xl">FAQ</h2>{faqs.map(f => <details key={f.q} className="glass mb-2 p-4"><summary className="cursor-pointer text-white">{f.q}</summary><p className="mt-2">{f.a}</p></details>)}</section></Page>);
}
