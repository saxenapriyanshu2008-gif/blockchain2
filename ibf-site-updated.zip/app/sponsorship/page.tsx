import Link from "next/link";
import Page from "@/components/Page";
import Form from "@/components/Form";
import { alumni, deckUrl, demographics, partnerGroups, perkNames, reach, tiers } from "@/data/pages";
export const metadata = { title: "Sponsorship" };
export default function Sponsorship() {
  const max = Math.max(...reach.map(r => r.v));
  return (<Page title="Partner with India's emerging student blockchain community" intro="Reach engaged student builders through events, hackathons and our online community.">
    <section className="grid gap-4 md:grid-cols-4">{["Brand visibility", "Talent access", "Community engagement", "Authentic Web3 presence"].map(b => <div key={b} className="glass p-5">{b}</div>)}</section>
    <section><h2 className="mb-3 text-2xl">Our reach</h2>{/* TODO: real analytics */}
      <div className="grid gap-3">{reach.map(r => <div key={r.label}><p className="text-sm">{r.label}: {r.v.toLocaleString("en-IN")}</p><div className="h-3 rounded bg-white/10"><div className="h-3 rounded bg-gradient-to-r from-volt to-violet" style={{ width: `${(r.v / max) * 100}%` }} /></div></div>)}</div>
      <div className="mt-6 grid gap-3">{demographics.map(d => <div key={d.label}><p className="text-sm">{d.label}: {d.pct}%</p><div className="h-3 rounded bg-white/10"><div className="h-3 rounded bg-ember" style={{ width: `${d.pct}%` }} /></div></div>)}</div></section>
    <section className="overflow-x-auto"><h2 className="mb-3 text-2xl">Sponsorship tiers</h2><table className="w-full min-w-[32rem] text-left text-sm"><thead><tr><th className="p-2">Benefit</th>{tiers.map(t => <th key={t.name} className="p-2 text-white">{t.name}<br /><span className="font-normal">{t.price}</span></th>)}</tr></thead>
      <tbody>{perkNames.map((p, i) => <tr key={p} className="border-t border-white/10"><td className="p-2">{p}</td>{tiers.map(t => <td key={t.name} className="p-2">{t.perks[i] ? "Included" : "Not included"}</td>)}</tr>)}</tbody></table></section>
    <section><h2 className="mb-3 text-2xl">Past sponsors</h2><p>{partnerGroups.Tech.join(", ")} {/* TODO */}</p></section>
    <section><h2 className="mb-3 text-2xl">Where our alumni go</h2><p>{alumni.join(" · ")}</p></section>
    <section className="flex flex-wrap gap-3"><Link href="/events" className="btn border border-white/20 text-white">See events to sponsor</Link><a href={deckUrl} target="_blank" rel="noopener noreferrer" className="btn bg-ember text-black">Download sponsorship deck</a></section>
    <section className="max-w-xl"><h2 className="mb-3 text-2xl">Sponsor inquiry</h2><Form type="sponsor" submit="Send inquiry" fields={[{ name: "company", label: "Company", required: true }, { name: "contact", label: "Contact person", required: true }, { name: "email", label: "Email", type: "email", required: true }, { name: "phone", label: "Phone", type: "tel" }, { name: "tier", label: "Tier interest", options: tiers.map(t => t.name) }, { name: "message", label: "Message", type: "textarea" }]} /></section></Page>);
}
