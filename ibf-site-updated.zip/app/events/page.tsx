import Form from "@/components/Form";
import { featuredEvent } from "@/data/site";
export const metadata = { title: "Upcoming events" };
export default function Events() { // TODO: event list from a data file with filters, plus /events/[slug] detail template
  return (<div className="mx-auto max-w-xl px-4 py-16"><h1 className="mb-2 text-4xl">Upcoming events</h1><p className="mb-6">{featuredEvent.title}: {featuredEvent.venue}</p>
    <Form type="event" submit="Register" fields={[{ name: "name", label: "Name", required: true }, { name: "email", label: "Email", type: "email", required: true }, { name: "event", label: "Event", options: [featuredEvent.title] }]} /></div>);
}
