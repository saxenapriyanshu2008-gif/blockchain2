import Page from "@/components/Page";
import { pastEvents } from "@/data/pages";
export const metadata = { title: "Past events" };
export default function Past() { // TODO: add photos and a /events/[slug] detail page per event
  return (<Page title="Past events"><div className="grid gap-4 md:grid-cols-2">{pastEvents.map(e => (
    <article key={e.title} className="glass p-6"><div className="mb-4 h-32 rounded-lg bg-gradient-to-br from-volt/30 to-violet/30" aria-hidden /><h2 className="text-xl">{e.title}</h2>
      <p className="text-sm">{e.date} · {e.attendees} attendees</p><p className="mt-2">{e.recap}</p><p className="mt-2 text-sm">Speakers: {e.speakers.join(", ")}</p></article>))}</div></Page>);
}
