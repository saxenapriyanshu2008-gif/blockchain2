import Link from "next/link";
import IntroSplash from "@/components/IntroSplash";
import GlassButton from "@/components/GlassButton";
import Counter from "@/components/Counter";
import ScrollGallery from "@/components/ScrollGallery";
import HeroFx from "@/components/HeroFx";
import HeroVideo from "@/components/HeroVideo";
import Countdown from "@/components/Countdown";
import { featuredEvent, initiatives, site, sponsors, stats } from "@/data/site";
export default function Home() {
  return (<>
    <IntroSplash />
    <section className="relative overflow-hidden">
      <HeroFx />
      {/* Banner shown whole (never cropped, never covered): the artwork already carries the title, logo and icons */}
      {/* soft blurred copy of the banner fills the very top, so the glass top bar floats over the picture */}
      <div aria-hidden className="absolute inset-x-0 top-0 h-[70vh] scale-110 bg-cover bg-top opacity-60 blur-xl [mask-image:linear-gradient(to_bottom,black,transparent)]" style={{ backgroundImage: "url(/hero.jpg)" }} />
      <div className="relative mx-auto w-full max-w-[1774px] pt-[96px] md:pt-[76px]">
        <HeroVideo />
      </div>
      {/* Page text sits below the banner, so nothing overlaps the artwork */}
      <div className="relative mx-auto max-w-6xl px-4 pb-10 pt-4 text-center md:pb-14 md:pt-6">
        <h1 className="mx-auto max-w-3xl text-[1.75rem] font-bold leading-tight sm:text-3xl md:text-5xl">{site.tagline}</h1>
        <p className="mx-auto mt-3 max-w-xl text-base md:mt-4 md:text-lg">{site.pitch}</p>
        <div className="mt-6 flex flex-wrap justify-center gap-2.5 md:mt-8 md:gap-3">
          <GlassButton href="/join" tone="blue">Join IBF</GlassButton>
          <GlassButton href="/events">Upcoming events</GlassButton>
          <GlassButton href="/sponsorship" tone="amber">Become a sponsor</GlassButton>
        </div>
      </div>
    </section>
    <section aria-label="Stats" className="mx-auto grid max-w-6xl grid-cols-2 gap-3 px-4 py-8 md:grid-cols-5 md:gap-4 md:py-10">
      {stats.map(s => <div key={s.label} className="glass p-4 last:col-span-2 md:last:col-span-1"><p className="font-display text-3xl text-white"><Counter value={s.value} /></p><p className="text-sm">{s.label}</p></div>)}
    </section>
    <section className="mx-auto max-w-6xl px-4 py-8 md:py-10"><div className="glass flex flex-col gap-5 p-5 md:flex-row md:gap-6 md:p-8 md:items-center md:justify-between">
      <div><h2 className="text-2xl">{featuredEvent.title}</h2><p className="mt-1">{featuredEvent.venue}</p><p className="mt-3 max-w-md">{featuredEvent.blurb}</p>
        <Link href="/events" className="btn mt-4 w-full justify-center bg-ember text-black md:w-auto">Register</Link></div>
      <Countdown to={featuredEvent.date} /></div></section>
    <section className="mx-auto grid max-w-6xl gap-3 px-4 py-8 md:grid-cols-3 md:gap-4 md:py-10">
      {initiatives.map(i => <Link key={i.title} href={i.href} className="glass p-5 md:p-6"><h3 className="text-xl">{i.title}</h3><p className="mt-2">{i.text}</p></Link>)}
    </section>
    <section aria-label="Past sponsors" className="w-full overflow-hidden py-8 md:py-10">
      <h2 className="mx-auto mb-6 max-w-6xl px-4 text-2xl">Our Past Sponsors</h2>
      <div className="[mask-image:linear-gradient(to_right,transparent,black_6%,black_94%,transparent)]"><div className="marquee-track flex w-max">
        {[0, 1].map(g => <div key={g} aria-hidden={g === 1} className="flex shrink-0 gap-4 pr-4">
          {sponsors.map(sp => <figure key={sp.name} className="flex w-44 shrink-0 flex-col items-center gap-2">
            <img src={`/sponsors/${sp.logo}.png`} alt={g === 0 ? `${sp.name} logo` : ""} loading="lazy" className="h-24 w-44 rounded-xl border border-white/10 bg-white/5 object-contain" />
            <figcaption className="text-sm text-white/70">{sp.name}</figcaption></figure>)}</div>)}</div></div></section>
    <ScrollGallery />

    {/* TODO: testimonials, final CTA banner, and the remaining pages */}
  </>);
}
