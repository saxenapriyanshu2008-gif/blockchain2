import Page from "@/components/Page";
import { stats } from "@/data/site";
import { timeline, values } from "@/data/pages";
export const metadata = { title: "About" };
export default function About() {
  return (<Page title="About IBF" intro="Our mission is to make blockchain education and building accessible to every student in India.">
    <section className="grid gap-4 md:grid-cols-2"><div className="glass p-6"><h2 className="text-xl">Vision</h2><p className="mt-2">A student-led Web3 ecosystem in every Indian campus. {/* TODO story */}</p></div>
      <div className="glass p-6"><h2 className="text-xl">What we do</h2><p className="mt-2">Events, hackathons, workshops and student projects.</p></div></section>
    <section><h2 className="mb-3 text-2xl">Values</h2><ul className="grid gap-3 md:grid-cols-4">{values.map(v => <li key={v} className="glass p-4">{v}</li>)}</ul></section>
    <section><h2 className="mb-3 text-2xl">Milestones</h2><ol className="border-l border-violet/50 pl-6">{timeline.map(t => <li key={t.y} className="mb-4"><b className="text-ember">{t.y}</b> {t.t}</li>)}</ol></section>
    <section aria-label="Impact" className="grid grid-cols-2 gap-4 md:grid-cols-5">{stats.map(s => <div key={s.label} className="glass p-4"><p className="font-display text-2xl text-white">{s.value.toLocaleString("en-IN")}+</p><p className="text-sm">{s.label}</p></div>)}</section>
  </Page>);
}
