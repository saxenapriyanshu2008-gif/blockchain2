import Link from "next/link";
import Page from "@/components/Page";
import { partnerGroups } from "@/data/pages";
export const metadata = { title: "Partners" };
export default function Partners() {
  return (<Page title="Partners">{Object.entries(partnerGroups).map(([g, ps]) => (
    <section key={g}><h2 className="mb-3 text-2xl">{g}</h2><ul className="grid grid-cols-2 gap-4 md:grid-cols-4">{ps.map(p => <li key={p} className="glass p-6 text-center">{p}</li>)}</ul></section>))}
    <Link href="/contact" className="btn w-fit bg-ember text-black">Partner with us</Link></Page>);
}
