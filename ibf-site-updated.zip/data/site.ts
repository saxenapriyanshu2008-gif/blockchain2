// TODO: all values below are placeholders — replace with real data.
export const site = { name: "Indian Blockchain Fraternity", short: "IBF", url: "https://ibf.example.com", // TODO
  tagline: "Decentralizing the Future, One Block at a Time.",
  pitch: "A student-led blockchain community at Bennett University building, learning and shipping Web3 across India." };
export const stats = [ // TODO
  { label: "Members", value: 1200 }, { label: "Events hosted", value: 45 },
  { label: "Chapters", value: 8 }, { label: "Partners", value: 20 }, { label: "Social reach", value: 50000 } ];
export const featuredEvent = { // TODO
  title: "IBF Hack: Build on Chain", date: "2026-12-12T09:00:00+05:30", venue: "Bennett University, Greater Noida",
  blurb: "A 24-hour hackathon with mentors, workshops and prizes for student builders." };
export const initiatives = [
  { title: "Hackathons", href: "/initiatives/hackathons", text: "24-hour builds with real prizes and mentors." },
  { title: "Workshops", href: "/initiatives/workshops", text: "Hands-on sessions from wallets to smart contracts." },
  { title: "Projects", href: "/initiatives/projects", text: "Student-built dApps, tools and research." } ];
export const partners = ["Partner A","Partner B","Partner C","Partner D","Partner E","Partner F"]; // TODO logos
export const nav = [
  { label: "About", href: "/about" },
  { label: "Events", href: "/events", children: [{ label: "Upcoming", href: "/events" }, { label: "Past", href: "/events/past" }] },
  { label: "Community", href: "/join", children: [{ label: "Join IBF", href: "/join" }, { label: "Core Team", href: "/team" }, { label: "Chapters", href: "/chapters" }] },
  { label: "Initiatives", href: "/initiatives/hackathons", children: initiatives.map(i => ({ label: i.title, href: i.href })) },
  { label: "Partners", href: "/partners" }, { label: "Sponsorship", href: "/sponsorship" },
  { label: "Resources", href: "/resources" }, { label: "Contact", href: "/contact" } ];

// Past sponsors: logo files live in /public/sponsors
export const sponsors = [
  { name: "Zealy", logo: "zealy" }, { name: "Blockchain School", logo: "blockchain-school" }, { name: "Supra", logo: "supra" }, { name: "Camp", logo: "camp" },
  { name: "Sui", logo: "sui" }, { name: "0G", logo: "og" }, { name: "DoraHacks", logo: "dorahacks" }, { name: "Flow", logo: "flow" },
  { name: "Tezos", logo: "tezos" }, { name: "Shardeum", logo: "shardeum" }, { name: "Rise In", logo: "rise-in" }, { name: "TON", logo: "ton" },
  { name: "OpenBuild", logo: "openbuild" }, { name: "Spheron", logo: "spheron" }, { name: "Pawnspace", logo: "pawnspace" }, { name: "Neo", logo: "neo" },
  { name: "HeLa", logo: "hela" }, { name: "Kite AI", logo: "kite-ai" }, { name: "Aptos", logo: "aptos" }, { name: "Delysium", logo: "delysium" } ];
